import sqlite3
from models.sentiment_model import classify_sentiment# <- Make sure import works

# Connect to your SQLite database
conn = sqlite3.connect("sentiment_logs.db")
cursor = conn.cursor()

# Fetch all logs
cursor.execute("SELECT id, message FROM sentiment_logs")  # Ensure 'id' column exists
rows = cursor.fetchall()

# Reprocess and update each message
for row in rows:
    log_id, message = row
    new_label, new_confidence = classify_sentiment(message)

    # Update sentiment and confidence in DB
    cursor.execute("""
        UPDATE sentiment_logs 
        SET emotion = ?, confidence = ?
        WHERE id = ?
    """, (new_label, new_confidence, log_id))

    print(f"[Updated] ID: {log_id}")
    print(f"Message: {message}")
    print(f"Emotion: {new_label}, Confidence: {new_confidence}")
    print("-" * 40)

# Commit changes and close
conn.commit()
conn.close()
