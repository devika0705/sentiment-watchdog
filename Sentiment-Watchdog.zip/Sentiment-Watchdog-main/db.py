from sqlalchemy import create_engine, Column, Integer, String, Float, DateTime, Index
from sqlalchemy.orm import declarative_base, sessionmaker
import os
from pathlib import Path
import datetime

# Initialize the base class for declarative class definitions
Base = declarative_base()

# ✅ Use dynamic path with pathlib
BASE_DIR = Path(__file__).resolve().parent
DATABASE_URL = f"sqlite:///{BASE_DIR / 'sentiment_logs.db'}"

# ✅ Create engine
engine = create_engine(DATABASE_URL, echo=True)


# Session maker for DB operations
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ✅ Updated Model
class SentimentLog(Base):
    __tablename__ = 'sentiment_logs'  # ✅ changed from 'sentiments'

    id = Column(Integer, primary_key=True, autoincrement=True)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow, index=True)  # ✅ indexing on timestamp
    message = Column(String, nullable=False)  # ✅ add basic validation
    emotion = Column(String, nullable=False)  # ✅ add basic validation
    confidence = Column(Float, nullable=False)  # ✅ add basic validation
    source = Column(String, default="chat")  # ✅ optional metadata
    user_id = Column(String, nullable=True)  # ✅ optional metadata

    # ✅ Optional: Define index explicitly if needed
    __table_args__ = (
        Index('ix_timestamp', 'timestamp'),
    )

# ✅ Initialize database
def init_db():
    Base.metadata.create_all(bind=engine)
