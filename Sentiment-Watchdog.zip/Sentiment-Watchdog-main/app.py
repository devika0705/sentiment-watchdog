from fastapi import FastAPI, Depends
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware  
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session
from sqlalchemy import create_engine
from dotenv import load_dotenv
import logging
import os
import csv

from models.sentiment_model import classify_sentiment
from db import SessionLocal, SentimentLog, engine
from slack_alert import send_alert

# ✅ Load environment variables
load_dotenv()

# ✅ Create log folder if it doesn't exist
os.makedirs("logs", exist_ok=True)

# ✅ Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    filename="logs/app.log",
    filemode="a"
)

# ✅ Define FastAPI app
app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # or specify exact frontend origin like ["http://localhost:3000"]
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ✅ Ticket schema with validation
class Ticket(BaseModel):
    message: str = Field(..., min_length=1, description="Support ticket message")
    source: str = "chat"
    user_id: str | None = None

# ✅ Negative emotions for alert
NEGATIVE_EMOTIONS = [
    "anger",
    "annoyance",
    "confusion",
    "disappointment",
    "disapproval",
    "disgust",
    "embarrassment",
    "fear",
    "grief",
    "nervousness",
    "remorse",
    "sadness"
]



# ✅ Dependency to get DB session
def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

# ✅ Analyze sentiment and store log
@app.post("/analyze")
def analyze_ticket(ticket: Ticket, db: Session = Depends(get_db)):
    logging.info(f"Received ticket: {ticket.message} from {ticket.source}, user: {ticket.user_id}")

    try:
        label, score = classify_sentiment(ticket.message)
    except Exception as e:
        logging.error(f"⚠️ Sentiment model failed: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": f"Sentiment classification failed: {str(e)}"}
     )


    logging.info(f"Predicted emotion: {label} ({score:.2f})")

    log = SentimentLog(
        message=ticket.message,
        emotion=label,
        confidence=score,
        source=ticket.source,
        user_id=ticket.user_id
    )
    try:
        last_log = db.query(SentimentLog).order_by(SentimentLog.timestamp.desc()).first()
        if last_log and last_log.message == ticket.message and last_log.emotion == label:
            return {"emotion": label, "confidence": round(score, 4)}  # Skip logging

        db.add(log)
        print(log.__dict__)
        db.commit()
    except Exception as e:
        logging.error(f"⚠️ Logging failed: {e}")
        return JSONResponse(
            status_code=500,
            content={"error": f"Failed to log sentiment to database: {str(e)}"}
        )



    if label.lower() in NEGATIVE_EMOTIONS:
        logging.warning(f"⚠️ Negative sentiment detected: {label} ({score:.2f})")
        send_alert(f"🚨 Alert: Detected *{label}* emotion with confidence {score:.2%} in recent feedback.")



    return {
        "emotion": label,
        "confidence": round(score, 4),
        "source": ticket.source,
        "user_id": ticket.user_id
    }

# ✅ Endpoint to fetch sentiment logs
@app.get("/logs")
def get_sentiment_logs(skip: int = 0, limit: int = 10, db: Session = Depends(get_db)):
    logs = db.query(SentimentLog).order_by(SentimentLog.timestamp.desc()).offset(skip).limit(limit).all()
    results = [
        {
            "message": log.message,
            "emotion": log.emotion,
            "confidence": log.confidence,
            "source": log.source,
            "user_id": log.user_id,
            "timestamp": log.timestamp.isoformat()
        }
        for log in logs
    ]
    return JSONResponse(content=results)
results = []

