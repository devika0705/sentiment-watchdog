# 💬 Customer Sentiment Watchdog

AI-powered sentiment monitoring tool for support teams. Built with FastAPI, Streamlit, HuggingFace, and SQLite.

## 🌐 Live Demo

- 🔗 API: https://your-backend.onrender.com
- 🎯 Dashboard: https://your-name.streamlit.app

## 🛠 Setup (Local)

```bash
pip install -r requirements.txt
python init_db.py
uvicorn app:app --reload
