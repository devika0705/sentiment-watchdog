# live_stream.py

import json
import time
import requests
import sqlite3
from fastapi import APIRouter

router = APIRouter()

@router.get("/test")
async def test_route():
    return {"message": "Live stream working"}

# ✅ Connect to SQLite DB (or use SQLAlchemy if preferred)
conn = sqlite3.connect("sentiment_logs.db")
cursor = conn.cursor()

# 🚫 Removed redundant CREATE TABLE (already done in init_db.py)

# ✅ Load sample ticket data
with open("../data/sample_tickets.json") as f:
    tickets = json.load(f)

# ✅ Process and log each ticket
for ticket in tickets:
    message = ticket['message']
    print(f"Sending: {message}")

    try:
        # ✅ Updated endpoint
        response = requests.post("http://127.0.0.1:8000/tickets", json={"message": message})

        if response.status_code != 200:
            print(f"❌ Bad response: {response.status_code}, {response.text}")
            continue  # 🛠️ Fix: only skip after printing error

        result = response.json()
        print("✅ Response:", result)

        # ✅ Insert into database
        cursor.execute(
            "INSERT INTO sentiment_logs (message, emotion, confidence) VALUES (?, ?, ?)",
            (message, result["emotion"], result["confidence"])
        )
        conn.commit()

    except Exception as e:
        print("❌ Error:", e)

    time.sleep(2)  # simulate delay
