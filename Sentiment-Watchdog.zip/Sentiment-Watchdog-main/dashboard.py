import streamlit as st
import requests
import pandas as pd
from sqlalchemy import create_engine
from datetime import datetime
import plotly.express as px
import matplotlib.pyplot as plt
from wordcloud import WordCloud
import seaborn as sns
import os
from pathlib import Path
from sqlalchemy import text
 



# ========== CONFIG ==========
st.set_page_config(page_title="Sentiment Watchdog", page_icon="💬", layout="wide")
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "sentiment_logs.db"  # Adjust if your DB is elsewhere
engine = create_engine(f"sqlite:///{DB_PATH}")

# ========== STYLING ==========
st.markdown("""
    <style>
        html, body, [class*="css"] {
            font-family: 'Segoe UI', sans-serif;
            background-color: #f7f9fc;
        }
        .title {
            font-size: 44px;
            font-weight: bold;
            color: #2f3e9e;
            text-align: center;
            margin-top: 20px;
        }
        .subtitle {
            font-size: 18px;
            color: #444;
            text-align: center;
            margin-bottom: 30px;
        }
        .result-box {
            background-color: #f0f2f5;
            padding: 20px;
            border-radius: 10px;
            margin-top: 15px;
        }
    </style>
""", unsafe_allow_html=True)

st.markdown('<div class="title">💬 Sentiment Watchdog Dashboard</div>', unsafe_allow_html=True)
st.markdown('<div class="subtitle">Monitor and visualize real-time customer sentiment</div>', unsafe_allow_html=True)

# ========== ANALYSIS SECTION ==========
st.header("📝 Real-Time Sentiment Analyzer")

col1, col2 = st.columns([3, 1])

with col1:
    user_input = st.text_area("Enter support message:", height=120)
    source_input = st.text_input("Source (optional)", value="dashboard")
    user_id_input = st.text_input("User ID (optional)")


with st.container():
    st.markdown('<div class="big-button">', unsafe_allow_html=True)
    analyze = st.button("🔍 Analyze")
    st.markdown('</div>', unsafe_allow_html=True)

if analyze and user_input:
    try:
        payload = {
            "message": user_input,
            "source": source_input if source_input.strip() else None,
            "user_id": user_id_input if user_id_input.strip() else None
        }
        response = requests.post("http://127.0.0.1:8000/analyze", json=payload)
        if response.status_code == 200:
            result = response.json()
            emotion = result["emotion"]
            confidence = result["confidence"]  # raw float, e.g., 0.87
 
            emoji_color_map = {
                "admiration":    ("😍", "#e6f7ff"),  # light blue
                "amusement":     ("😂", "#fff3cd"),  # light yellow
                "anger":         ("😠", "#f8d7da"),  # light red
                "annoyance":     ("😤", "#f8d7da"),
                "approval":      ("👍", "#d4edda"),  # light green
                "caring":        ("🤗", "#e8f5e9"),
                "confusion":     ("😕", "#f0f2f5"),  # grey
                "curiosity":     ("🧐", "#e3f2fd"),
                "desire":        ("😋", "#fde2e4"),
                "disappointment":("😞", "#f8d7da"),
                "disapproval":   ("👎", "#f8d7da"),
                "disgust":       ("🤢", "#f8d7da"),
                "embarrassment": ("😳", "#fff3cd"),
                "excitement":    ("🤩", "#e0f7fa"),
                "fear":          ("😨", "#fce4ec"),
                "gratitude":     ("🙏", "#e8f5e9"),
                "grief":         ("😭", "#f8d7da"),
                "joy":           ("😊", "#d4edda"),
                "love":          ("❤️", "#ffebee"),
                "nervousness":   ("😬", "#fff3cd"),
                "optimism":      ("🌟", "#e6ffed"),
                "pride":         ("😌", "#e6f7ff"),
                "realization":   ("💡", "#f0f0f0"),
                "relief":        ("😌", "#d4edda"),
                "remorse":       ("😔", "#f8d7da"),
                "sadness":       ("😢", "#f8d7da"),
                "surprise":      ("😲", "#fff3cd"),
                "neutral":       ("😐", "#d1d1d1")
        }

            emoji, color = emoji_color_map.get(emotion.lower(), ("❓", "#e2e3e5"))



            st.markdown(f"""
                <div class="result-box" style="background-color:{color};">
                    <h3>{emoji} Emotion: <b>{emotion}</b></h3>
                    <p>🔢 Confidence: <b>{confidence}%</b></p>
                </div>
            """, unsafe_allow_html=True)

            # Log to database
            try:
                with engine.begin() as conn:
                    insert_query = text("""
                        INSERT INTO sentiment_logs (timestamp, message, emotion, confidence)
                        VALUES (:timestamp, :message, :emotion, :confidence)
                    """)
                    conn.execute(insert_query, {
                        "timestamp": datetime.now(),
                        "message": user_input,
                        "emotion": emotion,
                        "confidence": confidence
                    })
            except Exception as db_err:
                st.warning(f"⚠️ Logging failed: {db_err}")
        else:
            st.error("⚠️ API returned an error.")
    except Exception as e:
        st.error(f"⚠️ Failed to connect to backend: {e}")
elif analyze:
    st.warning("Please enter a message before analyzing.")

# ========== TABS SECTION ==========
tab1, tab2, tab3 , tab4 = st.tabs(["📜 History", "📊 Trends", "📈 Charts", "📊 Sentiment Analytics"])

# ========== TAB 1: HISTORY ==========
with tab1:
    st.subheader("📜 Recent Sentiment Logs")
    try:
        df = pd.read_sql("SELECT * FROM sentiment_logs ORDER BY timestamp DESC LIMIT 100", engine)
        st.dataframe(df[['timestamp', 'message', 'emotion', 'confidence']])
    except Exception as e:
        st.error(f"Could not load history: {e}")

# ========== TAB 2: TRENDS ==========
with tab2:
    st.subheader("📉 Sentiment Over Time")
    try:
        df = pd.read_sql("SELECT * FROM sentiment_logs", engine)
        df['timestamp'] = pd.to_datetime(df['timestamp'])
        df['date'] = df['timestamp'].dt.date

        trend_data = df.groupby(['date', 'emotion']).size().unstack().fillna(0)
        st.line_chart(trend_data)
    except Exception as e:
        st.error(f"Could not generate trends: {e}")

# ========== TAB 3: CHARTS ==========
with tab3:
    st.subheader("📊 Sentiment Distribution")
    try:
        df = pd.read_sql("SELECT * FROM sentiment_logs", engine)

        pie_chart = px.pie(df, names='emotion', title='Sentiment Breakdown', hole=0.4)
        st.plotly_chart(pie_chart)

        time_chart = px.line(df, x='timestamp', y='confidence', color='emotion', markers=True,
                             title="Sentiment Confidence Over Time")
        
        if not df.empty:
            min_conf = df['confidence'].min()
            max_conf = df['confidence'].max()
            range_margin = (max_conf - min_conf) * 0.2 if (max_conf - min_conf) != 0 else 0.1
            time_chart.update_layout(
                yaxis=dict(range=[min_conf - range_margin, max_conf + range_margin])
            )

        st.plotly_chart(time_chart)
    except Exception as e:
        st.error(f"Could not load charts: {e}")

# ========== TAB 4: ADVANCED ANALYTICS ==========
with tab4:
    emotion_counts = {
        "admiration": 12,
        "amusement": 8,
        "anger": 15,
        "annoyance": 10,
        "approval": 14,
        "caring": 5,
        "confusion": 7,
        "curiosity": 9,
        "desire": 6,
        "disappointment": 11,
        "disapproval": 4,
        "disgust": 3,
        "embarrassment": 2,
        "excitement": 13,
        "fear": 6,
        "gratitude": 10,
        "grief": 2,
        "joy": 17,
        "love": 16,
        "nervousness": 4,
        "optimism": 9,
        "pride": 7,
        "realization": 6,
        "relief": 8,
        "remorse": 3,
        "sadness": 12,
        "surprise": 10,
        "neutral": 20
    }
    
    try:
        st.markdown("## 📊 Sentiment Analytics")

    # Emotion Count Bar Chart and Word Cloud side by side
        st.markdown("### 🔢 Emotion Count")
        emotion_counts_df = pd.DataFrame(list(emotion_counts.items()), columns=['emotion', 'count'])

        bar_chart = px.bar(
            emotion_counts_df,
            x='emotion',
            y='count',
            labels={'emotion': 'Emotion', 'count': 'Count'},
            color='emotion',
            title='Emotion Frequency'
        )
        st.plotly_chart(bar_chart, use_container_width=True)
        st.markdown("---")
        col1, col2 = st.columns(2)

        with col1:
            st.markdown("### ☁️ Word Cloud of All Texts")
            try:
                text_data = ' '.join(df['message'].dropna().astype(str).tolist())
                wordcloud = WordCloud(
                    width=800, height=400, background_color='white'
                ).generate(text_data)

                fig, ax = plt.subplots(figsize=(10, 5))
                ax.imshow(wordcloud, interpolation='bilinear')
                ax.axis('off')
                st.pyplot(fig)
            except Exception as e:
                st.warning(f"Could not generate word cloud: {e}")

        st.markdown("---")
            
        with col2:
            st.markdown("### 🔥 Emotion Heatmap by Hour")
            try:
                df['hour'] = pd.to_datetime(df['timestamp']).dt.hour
                heatmap_data = df.groupby(['hour', 'emotion']).size().unstack().fillna(0)

                fig, ax = plt.subplots(figsize=(12, 6))
                sns.heatmap(heatmap_data, cmap='YlGnBu', annot=True, fmt='g', linewidths=0.5)
                ax.set_title("Emotion Occurrence by Hour of Day", fontsize=14)
                ax.set_xlabel("Emotion")
                ax.set_ylabel("Hour of Day")
                st.pyplot(fig)
            except Exception as e:
                st.warning(f"Could not generate heatmap: {e}")

    except Exception as e:
        st.error(f"Could not load additional analytics: {e}")
