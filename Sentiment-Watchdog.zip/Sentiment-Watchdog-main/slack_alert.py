import os
import requests
from dotenv import load_dotenv
from models.sentiment_model import classify_sentiment

# Load environment variables from .env file
load_dotenv()

SLACK_WEBHOOK_URL = os.getenv("SLACK_WEBHOOK_URL")

def send_alert(message):
    if not SLACK_WEBHOOK_URL:
        print("⚠️ Missing Slack webhook URL. Skipping alert.")
        return

    payload = {
        "text": message
    }

    try:
        response = requests.post(SLACK_WEBHOOK_URL, json=payload)
        if response.status_code == 200:
            print("✅ Slack alert sent.")
        else:
            print(f"❌ Failed to send alert: {response.status_code} - {response.text}")
    except Exception as e:
        print(f"❌ Exception occurred: {e}")
